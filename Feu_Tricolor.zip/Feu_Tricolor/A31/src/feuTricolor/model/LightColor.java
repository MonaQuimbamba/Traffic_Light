package feuTricolor.model;

public enum LightColor
{
    GREEN,
    RED,
    ORANGE
  };
