package feuTricolor.model;

public abstract interface StrategyTraffic
{
  public abstract LightColor swicthColor(LightColor _color);

}
