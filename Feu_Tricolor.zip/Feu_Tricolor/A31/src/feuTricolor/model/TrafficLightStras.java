package feuTricolor.model;

public class TrafficLightStras
  implements StrategyTraffic
{
  private feuTricolor.model.LightColor color;

  /**
   * Permet d'obtenir la  LightColor
   * @return une LightColor
   */
  public LightColor swicthColor(LightColor _color)
  {
    LightColor res= null;
       switch (_color) 
       {
            case GREEN:
                    res = _color.ORANGE;
                    break;
            case ORANGE:
                    res = _color.RED;
                    break;
            case RED:
                    res = _color.GREEN;
                    break;
       }
    return res; 
  }

}
