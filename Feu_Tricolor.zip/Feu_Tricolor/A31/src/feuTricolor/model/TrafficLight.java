package feuTricolor.model;



import feuTricolor.control.Observable;

import java.awt.Color;


public class TrafficLight extends Observable
{

  private StrategyTraffic strategyTraffic;
  private Boolean _isOn = true;
  private LightColor _color = LightColor.RED;

  public TrafficLight()
  {
      strategyTraffic = new TrafficLightStras();
  }

  public Boolean getIsOn()
  {
    return _isOn;
  }

  public StrategyTraffic getStrategyTraffic()
  {
    return strategyTraffic;
  }

  public LightColor getColor()
  {
    return _color;
  }

  public void onOff()
  {
      _isOn = !_isOn;
      _color = LightColor.RED;
      notifyObservers( _color, _isOn );
  }

  public void swicthColor() 
  {  
    
      setColor(getStrategyTraffic().swicthColor(_color));
       notifyObservers( _color, _isOn ) ;
    
  
  }
  

  public void setColor(LightColor _color)
  {
    this._color = _color;
  }

  public void setIsOn(Boolean _isOn)
  {
    this._isOn = _isOn;
  }

  public void setStrategyTraffic(StrategyTraffic strategyTraffic)
  {
    this.strategyTraffic = strategyTraffic;
  }

}

