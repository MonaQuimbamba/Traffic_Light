package feuTricolor.model;

public abstract interface TrafficLightObserver
{
  public abstract void update(LightColor color, Boolean ison);
}
