package feuTricolor.model;

import java.awt.Color;

public class TrafficLightKehl implements StrategyTraffic
{
  /**
   * @attributs it�rateurs  pour changer le feu selon la sequence red->orange->green->orange->red
   * */
  int i=1;
  int j=1;
  /**
   * Permet d'obtenir la  LightColor
   * @return une LightColor
   */
  public LightColor swicthColor(LightColor _color)
  {
    LightColor res=null;
   
    while(i<5) 
    {
                                    
      if(i==1) {i++; res = _color.ORANGE; break;} // si i est �gal � 1 res = Red et incr�ment i                         
      else if(i==2)   // si i =2 incr�ment i et on test les deux condition 
      {    i++;
            if(j%2==0){res = _color.GREEN;j++;break;} // si j%2==0 res=green incr�ment j pour passer d'un num�ro pair � un numero impair
           else { res = _color.RED;j++;break;}// sinon res=red incr�ment j pour passer d'un num�ro impair � un numero pair
      }                                   
      else if(i==3) {i++; res = _color.ORANGE; break;} // si i=3 res=orange
      if(i==4){i=2;} // si i=4 retour dans la condition i=2 pour prendre soit red soit green
    }   
    return res;
  }
  
}
