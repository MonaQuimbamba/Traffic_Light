package feuTricolor.control;

import feuTricolor.model.TrafficLight;

import feuTricolor.model.TrafficLightKehl;
import feuTricolor.model.TrafficLightStras;

import feuTricolor.view.DecoraterPedestrian;
import feuTricolor.view.DecoraterTurnRight;
import feuTricolor.view.GraphicalLight;
import feuTricolor.view.TextualLight;
import feuTricolor.view.TrafficLightView;

public class TrafficManager
{

  /**
     * @attribute TrafficLight cr�er une instance de feu
     */
  private static TrafficLight trafficLight = new TrafficLight();
  /**
   * @attribut change , pour changer la strategie
   * */
  boolean change=true;
  public TrafficManager() {}

  /**
     * Permet d'obtenir une TrafficLightView 
     * @return une graphicalLight
     */
  public TrafficLightView getViewG()
  {
      GraphicalLight g = GestionViewLight.getInstance().createGraphicalLight(trafficLight);
      trafficLight.add(g);
      return g;
  }
  
  /**
     * Permet d'obtenir une TrafficLightView 
     * @return une textualLight
     */
  public TrafficLightView getViewT()
  {
      TextualLight t = GestionViewLight.getInstance().createTextualLight(trafficLight);
      trafficLight.add(t);
      return t;
  }
  
  /**
     * Permet d'obtenir une TrafficLightView 
     * @return une decoratetPedestrian
     */
  public TrafficLightView getViewP()
  {
      DecoraterPedestrian p = GestionViewLight.getInstance().createDecoratePedestrian(trafficLight);
      trafficLight.add(p);
      return p;
  }
  /**
     * Permet d'obtenir une TrafficLightView 
     * @return une DecoraterTurnRight
     */
  public TrafficLightView getViewTR()
  {
      DecoraterTurnRight tr = GestionViewLight.getInstance().createDecorateTurnRight(trafficLight);
      trafficLight.add(tr);
      return tr;
  }
  
  /**
     * Permet de changer la strategie
     * 
     */
  public void changeStrategy()
  { 
     if(change)
     {trafficLight.setStrategyTraffic(new TrafficLightKehl());change=false;}
     else{trafficLight.setStrategyTraffic(new TrafficLightStras());change=true;} }

  public TrafficLight getTrafficLight()
  {
    return trafficLight;
  }

  public boolean isChange()
  {return change;}
  
}
