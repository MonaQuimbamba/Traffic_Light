package feuTricolor.control;

import feuTricolor.model.LightColor;

public abstract interface TrafficLightObserver
{
  public abstract void update( LightColor color, Boolean isOn );


}
