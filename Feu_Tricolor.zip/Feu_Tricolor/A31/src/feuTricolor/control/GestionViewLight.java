package feuTricolor.control;

import feuTricolor.view.DecoraterPedestrian;
import feuTricolor.view.DecoraterTurnRight;

import feuTricolor.model.TrafficLight;

import feuTricolor.view.GraphicalLight;
import feuTricolor.view.TextualLight;
import feuTricolor.view.TrafficLightView;

public class GestionViewLight
{
  
  /**@attribut static de GestionViewLight
   * */
  private static GestionViewLight gestionViewLight=null;
  
  /**@attribut TrafficLightView
   * */
  private TrafficLightView trafficLightView;

  private GestionViewLight(){}

    /**
     * Permet d'obtenir une instance de GestionViewLight, null si elle n'a pas ete instancie.
     * @return une instance de GestionViewLight ou null.
     */
  public static GestionViewLight getInstance()
  {
    if(gestionViewLight==null)
    { gestionViewLight = new GestionViewLight();}
    return gestionViewLight;
  }

  /**
   * Permet d'obtenir une instance de GraphicalLight,
   * @return une instance de GraphicalLight
   */
  public GraphicalLight createGraphicalLight(TrafficLight tl)
  {
      trafficLightView = new GraphicalLight( tl );
      
      return (GraphicalLight)trafficLightView;
  }
  
  /**
   * Permet d'obtenir une instance de TextualLight,
   * @return une instance de TextualLight
   */
  public TextualLight createTextualLight(TrafficLight tl)
  {
      trafficLightView = new TextualLight( tl );
      return (TextualLight)trafficLightView;
  }

  /**
   * Permet d'obtenir une instance de DecoraterPedestrian,
   * @return une instance de DecoraterPedestrian
   */
  public DecoraterPedestrian createDecoratePedestrian(TrafficLight tl)
  {
      trafficLightView = new DecoraterPedestrian(tl,trafficLightView);
      return (DecoraterPedestrian)trafficLightView;
 
  }

  /**
   * Permet d'obtenir une instance de createDecorateTurnRight,
   * @return une instance de createDecorateTurnRight
   */
  public DecoraterTurnRight createDecorateTurnRight(TrafficLight tl)
  {
      trafficLightView = new DecoraterTurnRight(tl,trafficLightView);
      return (DecoraterTurnRight)trafficLightView;
  }


}
