package feuTricolor;

import java.util.ArrayList;
    import java.awt.Button;
    import java.awt.GridLayout;
    import java.awt.event.ActionEvent;
    import javax.swing.JButton;
    import javax.swing.JFrame;
    import java.awt.Color;
    import java.awt.Dimension;
    import java.awt.event.ActionListener;

    import java.util.ArrayList;

    import java.util.Hashtable;

import java.util.Random;

import javax.swing.JMenu;
    import javax.swing.JMenuBar;
    import javax.swing.JPanel;


public class Class1 extends JFrame
{
    /* public static void main(String[] args) {
        String d = "zdhbzknlzdnlvdz,mzv,v"+"1";
        ArrayList<String> t = new ArrayList<String>();
        t.add("g");
        t.add("j");
        System.out.println(t.size());
         System.out.println(d.substring(0, d.length()-2));
        System.out.println(d.charAt(d.length()-1)); 
        
        
       // private ArrayList<StrategieChangerEtat> strategieChangerEtat;
    } */
    
    

   



        public ArrayList<JButton> listbutton = new ArrayList<JButton>();
        /*  public Grille g ;
        public Grille g1; */
        private Integer x1,y1;
        private Boolean joueur1 = false;
          
          public Class1(Integer x,Integer y,Integer firstPerso,Integer tour,String extension,Integer nombrecell)
          {
           
              if(firstPerso == 0){
                  System.out.println("Cest au joueur 2 de commencer a placer ");
              }
              else{
                  System.out.println("Cest au joueur 1 de commencer a placer ");
                  joueur1 = true;
              }
            /*  g = new Grille(x,y);
            g1 = new Grille(x,y); */
            
            x1 = x;
            y1=y;
            
            
            
            
            this.setTitle("Grille de jeu");
            this.setSize(600, 600);
            this.setDefaultCloseOperation(JFrame.EXIT_ON_CLOSE);
            this.setLocationRelativeTo(null);

            JPanel panel = new JPanel();
            JMenuBar jmenu = new JMenuBar();
            JMenu menu1 = new JMenu(" MENU  "); 
            JMenu menu2 = new JMenu(" " + extension); 
            JMenu menu3 = new JMenu("Tour"+tour.toString()); 
            JMenu menu4 = new JMenu("J1 : 0 / "+nombrecell.toString());
            JMenu menu5 = new JMenu("J2 : 0 / "+nombrecell.toString());
            
            jmenu.add(menu1);
            jmenu.add(menu2);
            jmenu.add(menu3);
            jmenu.add(menu4);
            jmenu.add(menu5);
            
            
            this.add(jmenu);
            setJMenuBar(jmenu);
         
            
            panel.setLayout(new GridLayout(x, y));

            for (int i= 1 ; i < (x*y)+1 ; i++) {
                JButton j = new JButton("");
                j.setBackground(Color.white);
                j.addActionListener(e -> actionPerformed(j));
                panel.add(j);
                listbutton.add(j);
             
                
                
            }
            
            JButton j1 = new JButton("ok");
            this.add(j1);
            
            this.add(panel);
            this.setVisible(true);

               

        }
          
       public void actionPerformed(JButton j){
           for(int i = 0;i<listbutton.size();i++){
               
             //  System.out.println(i);
               //System.out.println(i%x1);
               //System.out.println(i/y1);
               
               if(listbutton.get(i) == j){
                   if(joueur1){
                   System.out.println("J1 : ("+i%x1+","+i/y1+")");
                   if(j.getBackground()== Color.white){
                       j.setBackground(Color.black);
                     //  g.getCellules()[i%x1][i/y1].setEtat();
                      // System.out.println(g.getCellules()[i%x1][i/y1].estEnVie().toString());
                       joueur1 = false;
                   }
                   else{
                      j.setBackground(Color.white);
                     //  g.getCellules()[i%x1][i/y1].setEtat();
                       //System.out.println(g.getCellules()[i%x1][i/y1].estEnVie().toString());
                       joueur1 = false;
                   }}
                   else{
                       System.out.println("J2 : ("+i%x1+","+i/y1+")");
                       if(j.getBackground()== Color.white){
                           j.setBackground(Color.blue);
                         //  g1.getCellules()[i%x1][i/y1].setEtat();
                          // System.out.println(g1.getCellules()[i%x1][i/y1].estEnVie().toString());
                           joueur1 = true;
                       }
                       else{
                          j.setBackground(Color.white);
                           //g1.getCellules()[i%x1][i/y1].setEtat();
                           //System.out.println(g1.getCellules()[i%x1][i/y1].estEnVie().toString());
                           joueur1 = true;
                       }
                   }
                                                          
               }
           }
           
           for(int i = 0; i<x1; i++)
           {
               //for(int j = 0; j<y1; j++)
               {
                   //System.out.print(g1.getCellules()[i][j]);
               }
               System.out.println();
           }
        
       }
        
          
        public static void main(String[] args) 
        {
            
          //  int valeur = 1 + r.nextInt(19 - 1);

           // new Class1(15,5,7,4,"ffg",7);
            int i=0;
                while(i<18){
            System.out.println(Math.random());
                    i++;
                    }
        }
    
}
