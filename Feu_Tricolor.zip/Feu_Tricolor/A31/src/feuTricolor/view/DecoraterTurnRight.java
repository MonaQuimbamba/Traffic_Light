package feuTricolor.view;

import feuTricolor.model.LightColor;
import feuTricolor.model.TrafficLight;

import java.awt.BorderLayout;
import java.awt.Color;
import java.awt.event.ActionEvent;
import java.awt.event.ActionListener;

import javax.swing.JPanel;
import javax.swing.Timer;

public class DecoraterTurnRight
  extends DecorateTraffic
{
  
  /**
       * @attribute Panel color
       */
  private JPanel _colorPanel;
  
  /**@attribut timer
   * */ 
  javax.swing.Timer time;
  public DecoraterTurnRight(TrafficLight trafficLight, TrafficLightView view)
  {
    super(trafficLight,view);
    this.setTitle("TurnRigh view");

    _colorPanel = new JPanel();
    _colorPanel.setBackground(Color.GRAY);
    this.getContentPane().add(_colorPanel, BorderLayout.CENTER);

    ActionListener action = new ActionListener(){        
    public void actionPerformed(ActionEvent evt) 
    {
        if(_colorPanel.getBackground() == java.awt.Color.ORANGE)
            _colorPanel.setBackground(java.awt.Color.gray);
        else if(getBackground() == java.awt.Color.gray)
            _colorPanel.setBackground(java.awt.Color.ORANGE);
        else
            _colorPanel.setBackground(java.awt.Color.ORANGE);
    }};
    
    
    time = new Timer(500,action);
    this.setVisible(true);
  }

  /**
     * Permet de changer la couleur du decorateur selon leur parent
     */
  @Override
  public void update(LightColor color, Boolean isOn)
  {
    if(isOn)
  {
      if(color == LightColor.RED) 
           {time.start();}
    else{         _colorPanel.setBackground(java.awt.Color.gray);
          time.stop();}
  }
  
  }

  

}
