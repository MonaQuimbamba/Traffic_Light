package feuTricolor.view;

import feuTricolor.control.GestionViewLight;
import feuTricolor.control.TrafficLightObserver;

import feuTricolor.model.LightColor;
import feuTricolor.model.TrafficLight;

import java.awt.BorderLayout;

import java.awt.FlowLayout;
import java.awt.event.ActionEvent;
import java.awt.event.ActionListener;
import javax.swing.AbstractAction;
import javax.swing.JButton;
import javax.swing.JFrame;
import javax.swing.JInternalFrame;
import javax.swing.JPanel;


public abstract class TrafficLightView  extends JInternalFrame implements TrafficLightObserver {

	private TrafficLight _trafficLight;
	public TrafficLightView( TrafficLight trafficLight ) 
        {
	  super("TrafficLightView",false,false,false,false);
	        this.setSize(200, 200);
	        this.setTitle("ViewTrafficLight");
	        this.setVisible(true);
	        this.setLayout(new BorderLayout());
  	        
                _trafficLight = trafficLight; 
	        JPanel buttons = new JPanel();
                buttons.add( new JButton( new AbstractAction("On/Off") 
                {
                  @Override
                  public void actionPerformed(ActionEvent arg0) {_trafficLight.onOff();}}));
                  buttons.add( new JButton( new AbstractAction("Change color") 
                  {@Override
                  public void actionPerformed(ActionEvent arg0) {_trafficLight.swicthColor();}}));
	                        this.getContentPane().add(buttons, BorderLayout.SOUTH);}

  public TrafficLight getTrafficLight()
  {
    return _trafficLight;
  }
}


