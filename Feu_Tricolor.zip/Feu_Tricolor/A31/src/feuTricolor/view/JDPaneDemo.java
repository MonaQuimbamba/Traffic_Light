package feuTricolor.view;

import feuTricolor.TrafficManager;

import javax.swing.JFrame;
import java.awt.BorderLayout;  
import java.awt.Container;

import java.awt.Dimension;
import java.awt.Toolkit;

import java.awt.event.ActionEvent;

import java.util.ArrayList;

import javax.swing.AbstractAction;
import javax.swing.ImageIcon;
import javax.swing.JButton;
import javax.swing.JDesktopPane;  
import javax.swing.JFrame;  
import javax.swing.JInternalFrame;  
import javax.swing.JLabel;
import javax.swing.JPanel;
import javax.swing.SwingConstants;

public class JDPaneDemo extends JFrame
{
  

  /**
   * @attribute image des drapeux
   */
  private static ImageIcon flagstras = new ImageIcon("feu/france.jpg");
  private static ImageIcon flagKehl = new ImageIcon("feu/german.jpg");
  
  JPanel pnFlag = new JPanel();
  private TrafficManager tm;
  
   /**
   * @attribute la liste de trafficLightView 
   */
  
  private  ArrayList<JInternalFrame> listOfView = new ArrayList<JInternalFrame>();
   
  public JDPaneDemo()   
  {  
    JDesktopPane desktopPane = new JDesktopPane();  
    Container contentPane = getContentPane();  
    contentPane.add(desktopPane, BorderLayout.CENTER);  
  
 
  
    tm = new TrafficManager();
    
    /**************************************************************/
    JButton btnFlag = new JButton();
    btnFlag.setIcon(flagstras);
    btnFlag.setSize(13, 10);
    
    pnFlag.add(btnFlag);
 
  
    
     JPanel buttons = new JPanel();
    buttons.add( new JButton( new AbstractAction("Add Graphical View") 
    {
      @Override
     public void actionPerformed(ActionEvent arg0) { this.displayGraphical(desktopPane);}

      /**
         * fonction qui permet d'ajouter la vue graphique dans la desktopPane
         *
         */
      private void displayGraphical(JDesktopPane desktopPane)
      {
        JInternalFrame jif =tm.getViewG();
        jif.setBounds(30, 30, 200, 200);
        listOfView.add(jif);
        desktopPane.add(jif); 
        jif.setVisible(true);
      }
    }));
    
      buttons.add( new JButton( new AbstractAction("Add Textual View") 
      { @Override
        public void actionPerformed(ActionEvent arg0) {this.displayTextual(desktopPane);}

      /**
         * fonction qui permet d'ajouter la vue textuelle dans la desktopPane
         *
         */
      private void displayTextual(JDesktopPane desktopPane)
      {
         
        JInternalFrame jif =tm.getViewT();
        jif.setBounds(315, 30, 200, 200);
          listOfView.add(jif);
          desktopPane.add(jif); 
          jif.setVisible(true); 
      }
    }));
      
     buttons.add( new JButton( new AbstractAction("Add View Pedestrien") 
    {@Override
     public void actionPerformed(ActionEvent arg0) { this.displayPedestrian(desktopPane);}

      /**
         * fonction qui permet d'ajouter la vue pi�ton dans la desktopPane
         *
         */
      private void displayPedestrian(JDesktopPane desktopPane)
      {
        JInternalFrame jif =tm.getViewP();
        jif.setBounds(315,250, 200, 200);
          listOfView.add(jif);
          desktopPane.add(jif); 
          jif.setVisible(true);
      }
    }));
    
      buttons.add( new JButton( new AbstractAction("Add View Turn Right") 
      { @Override
        public void actionPerformed(ActionEvent arg0) {this.displayTurnRight(desktopPane);}


      /**
         * fonction qui permet d'ajouter la vue turn right dans la desktopPane
         *
         */
      private void displayTurnRight(JDesktopPane desktopPane)
      {
        JInternalFrame jif =tm.getViewTR();
        jif.setBounds(30, 250, 200, 200);
          listOfView.add(jif);
          desktopPane.add(jif); 
          jif.setVisible(true);
      }
    }));
    
      buttons.add( new JButton( new AbstractAction("Remove View")
      {@Override
      public void actionPerformed(ActionEvent arg0) {this.displayGraphicalR(desktopPane);}

      /**
         * fonction qui permet supprimer les vues dans la desktopPane
         *
         */
      private void displayGraphicalR(JDesktopPane desktopPane)
      {
        this.getListOfView().get(0).dispose();
        listOfView.remove(0);
      }
      /**
         * Permet d'obtenir une copie de la liste de trafficLightView  contenant toutes les instances
         * @return une copie de la liste de trafficLightView  contenant toutes les instances.
         */
      private  ArrayList<JInternalFrame>  getListOfView()
      {
        return listOfView ;
      }
    }));
      
     buttons.add( new JButton( new AbstractAction("Change Strategy")
    {@Override
    public void actionPerformed(ActionEvent arg0) {this.displayChange();}
     
      /**fonction permettant de changer la strategie*/
      private void displayChange( )
      {tm.changeStrategy();
       if(tm.isChange())
       {btnFlag.setIcon(flagstras);}
       else{btnFlag.setIcon(flagKehl);}}
    }));
      
    this.getContentPane().add(buttons, BorderLayout.NORTH);
    this.getContentPane().add(pnFlag, BorderLayout.WEST);
  

  
    setTitle("TrafficLight");  
    setSize(900, 600); 
    Dimension dim = Toolkit.getDefaultToolkit().getScreenSize();
    this.setLocation(dim.width/2-this.getSize().width/2, dim.height/2-this.getSize().height/2);
    setVisible(true);  
  }

}
