package feuTricolor.view;

import feuTricolor.model.LightColor;
import feuTricolor.model.TrafficLight;

public abstract class DecorateTraffic
  extends TrafficLightView
{
  /**
   * @attribut Parent trafficLightView
   */
  private TrafficLightView trafficLightView;

  public DecorateTraffic(TrafficLight trafficLight, TrafficLightView view)
  {
    super(trafficLight);
    trafficLightView=view;
    
  }

  /**
     * Permet d'obtenir une instance de trafficLightView
     * @return une instance de trafficLightView.
     */
  public TrafficLightView getTrafficLightView()
  {
    return trafficLightView;
  }

  public abstract void update( LightColor color, Boolean isOn );
  
  @Override
  public TrafficLight getTrafficLight()
  {
    return super.getTrafficLight();
  }
}
