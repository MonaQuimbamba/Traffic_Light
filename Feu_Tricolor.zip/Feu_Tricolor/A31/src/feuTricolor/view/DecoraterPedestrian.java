package feuTricolor.view;

import feuTricolor.model.LightColor;
import feuTricolor.model.TrafficLight;
import feuTricolor.model.TrafficLightKehl;

import java.awt.BorderLayout;
import java.awt.Color;

import javax.swing.JPanel;

public class DecoraterPedestrian
  extends DecorateTraffic
{
  /**
       * @attribute Panel color
       */
  private JPanel _colorPanel;
  public DecoraterPedestrian(TrafficLight trafficLight, TrafficLightView view)
  {
    super(trafficLight,view);
    
    this.setTitle("Pedestrien view");

    _colorPanel = new JPanel();
    _colorPanel.setBackground(Color.GRAY);
    this.getContentPane().add(_colorPanel, BorderLayout.CENTER);
    
    this.setVisible(true);
  }

  /**
     * Permet de changer la couleur du decorateur selon leur parent
     */
  @Override
  public void update( LightColor color, Boolean isOn )
  {
    if(isOn)
    {  
      if(super.getTrafficLight().getStrategyTraffic().getClass()==TrafficLightKehl.class)
      {
          if(color==LightColor.RED)
          { _colorPanel.setBackground(Color.GREEN);}
          
          if(color==LightColor.GREEN || color==LightColor.ORANGE)
          { _colorPanel.setBackground(Color.RED);}
        
      }
        
         
       
    }
  }


  }
