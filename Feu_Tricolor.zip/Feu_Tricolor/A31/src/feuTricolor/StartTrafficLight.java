package feuTricolor;



import feuTricolor.view.JDPaneDemo;


import java.util.Collection;

public class StartTrafficLight
{
  public static void main(String[] args)
  {
    new JDPaneDemo();
  }
}
