package feuTricolor;

import feuTricolor.view.DecorateTraffic;
import feuTricolor.model.LightColor;
import feuTricolor.model.TrafficLight;

import feuTricolor.model.TrafficLightKehl;


import feuTricolor.view.TrafficLightView;

import java.awt.BorderLayout;

import java.awt.Color;

import javax.swing.JPanel;


